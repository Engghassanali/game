import React from 'react'

export default function about() {
  return (
    <div>This is about</div>
  )
}

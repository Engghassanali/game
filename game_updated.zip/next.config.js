/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
}

clientId = "228215303308-orebjvddn5u465ummili56icm89q66ce.apps.googleusercontent.com",
clientSecret = "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"

module.exports = nextConfig
